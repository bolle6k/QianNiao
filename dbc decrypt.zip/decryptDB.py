import base64, re, tkinter as tk
from tkinter import simpledialog, messagebox, filedialog, ttk
from Blowfish import Blowfish, p_array, s_box
import os
import threading
IPC_DB = "ipc.db"
OUTPUT_DB = "ipc_patched.db"

FEATURE_MAPPING = [
    # -- VOLLSTÄNDIGE 119er Mapping-Liste! --
    "hostname_flag","hostname_from_dhcp","hostname_rebootneeded","http_flag","http_enable","http_ports",
    "https_flag","https_enable","https_ports","rtsp_flag","rtsp_enable","rtsp_ports","mail_from_account",
    "mail_from_name","mail_smtpserver","mail_smtpport","mail_username","mail_password","mail_snapshot",
    "mail_to_account","mail_to_name","mail_ssl","ntp_from_dhcp","ntp_port","ntp_cycle","ntp_server",
    "imgset_token","imgset_flag1","imgset_flag2","imgset_backlightcompensationmode","imgset_backlightcompensationlevel",
    "imgset_brightness","imgset_colorsaturation","imgset_contrast","imgset_exposuremode","imgset_exposurepriority",
    "imgset_exposurewindowbottom","imgset_exposurewindowtop","imgset_exposurewindowright","imgset_exposurewindowleft",
    "imgset_minexposuretime","imgset_maxexposuretime","imgset_exposuremingain","imgset_exposuremaxgain",
    "imgset_exposureminiris","imgset_exposuremaxiris","imgset_exposureexposuretime","imgset_exposuregain",
    "imgset_exposureiris","imgset_autofocusmode","imgset_focusdefaultspeed","imgset_focusnearlimit",
    "imgset_focusfarlimit","imgset_ircutfilter","imgset_sharpness","imgset_widedynamicmode",
    "imgset_widedynamicrangelevel","imgset_whitebalancemode","imgset_whitebalancecrgain",
    "imgset_whitebalancecbgain","imgset_begintime","imgset_ircutontime","imgset_ircutofftime",
    "imgset_rotate","imgset_mirror","imgset_flip","imgset_ldr","img_light_mode","img_star_light_enable",
    "img_style","imgmoveopt_flag","imgmoveopt_absolutepositionmin","imgmoveopt_absolutepositionmax",
    "imgmoveopt_absolutespeedmin","imgmoveopt_absolutespeedmax","imgmoveopt_relativedistancemin",
    "imgmoveopt_relativedistancemax","imgmoveopt_relativespeedmin","imgmoveopt_relativespeedmax",
    "imgmoveopt_continuousspeedmin","imgmoveopt_continuousspeedmax","imgopt_flag1","imgopt_flag2",
    "imgopt_backlightcompensationlevelmin","imgopt_backlightcompensationlevelmax","imgopt_brightnessmin",
    "imgopt_brightnessmax","imgopt_colorsaturationmin","imgopt_colorsaturationmax","imgopt_contrastmin",
    "imgopt_contrastmax","imgopt_exposureminexposuretimemin","imgopt_exposureminexposuretimemax",
    "imgopt_exposuremaxexposuretimemin","imgopt_exposuremaxexposuretimemax","imgopt_exposuremingainmin",
    "imgopt_exposuremingainmax","imgopt_exposuremaxgainmin","imgopt_exposuremaxgainmax",
    "imgopt_exposureminirismin","imgopt_exposureminirismax","imgopt_exposuremaxirismin",
    "imgopt_exposuremaxirismax","imgopt_exposureexposuretimemin","imgopt_exposureexposuretimemax",
    "imgopt_exposuregainmin","imgopt_exposuregainmax","imgopt_exposureirismin","imgopt_exposureirismax",
    "imgopt_focusdefaultspeedmin","imgopt_focusdefaultspeedmax","imgopt_focusnearlimitmin",
    "imgopt_focusnearlimitmax","imgopt_focusfarlimitmin","imgopt_focusfarlimitmax","imgopt_sharpnessmin",
    "imgopt_sharpnessmax","imgopt_widedynamicrangelevelmin","imgopt_widedynamicrangelevelmax",
    "imgopt_whitebalanceyrgainmin","imgopt_whitebalanceyrgainmax","imgopt_whitebalanceybgainmin",
    "imgopt_whitebalanceybgainmax","imgset_mode"
]
while len(FEATURE_MAPPING) < 119:
    FEATURE_MAPPING.append(f"reserved_{len(FEATURE_MAPPING)}")

BASE64_REGEX = re.compile(rb'[A-Za-z0-9+/=]{12,}')

def decrypt_block_bf(b64data, bf):
    raw = base64.b64decode(b64data)
    padded = raw + b"\x00"*((8 - len(raw)%8)%8)
    return bf.decrypt(padded)[:len(raw)]

def encrypt_block_bf(clear, bf):
    padded = clear + b"\x00"*((8 - len(clear)%8)%8)
    enc = bf.encrypt(padded)[:len(clear)]
    return base64.b64encode(enc)

class FullhanDBGUI(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Fullhan IPC DB-Editor (Blowfish, 119 Felder)")
        self.geometry("970x650")
        self.resizable(True, True)
        self.bf = Blowfish(p_array, s_box)
        self.tokens = []
        self.db_bytes = b""
        self.load_db()
        self.create_widgets()

    def load_db(self):
        with open(IPC_DB, "rb") as f:
            self.db_bytes = f.read()
        self.tokens = BASE64_REGEX.findall(self.db_bytes)

    def create_widgets(self):
        self.tree = ttk.Treeview(self, columns=("Index", "Feature", "HEX", "ASCII", "Edit"), show="headings")
        self.tree.heading("Index", text="Idx")
        self.tree.heading("Feature", text="Feature")
        self.tree.heading("HEX", text="HEX")
        self.tree.heading("ASCII", text="ASCII")
        self.tree.heading("Edit", text="Bearbeiten")
        self.tree.column("Index", width=35)
        self.tree.column("Feature", width=220)
        self.tree.column("HEX", width=220)
        self.tree.column("ASCII", width=230)
        self.tree.column("Edit", width=80)
        self.tree.pack(fill=tk.BOTH, expand=True)

        self.load_table()
        btn_save = tk.Button(self, text="Geänderte DB speichern", command=self.save_db)
        btn_save.pack(pady=6)

    def load_table(self):
        self.tree.delete(*self.tree.get_children())
        for idx, token in enumerate(self.tokens):
            feature = FEATURE_MAPPING[idx] if idx < len(FEATURE_MAPPING) else f"reserved_{idx}"
            clear = decrypt_block_bf(token, self.bf)
            hexval = clear.hex()
            try:
                ascii_val = clear.decode('utf-8').strip()
            except:
                ascii_val = ''.join(chr(c) if 32 <= c < 127 else '.' for c in clear).strip()
            self.tree.insert('', 'end', values=(idx, feature, hexval, ascii_val, "ändern"))
        self.tree.bind("<Double-1>", self.edit_value)

    def edit_value(self, event):
        rowid = self.tree.selection()[0]
        idx = int(self.tree.item(rowid, 'values')[0])
        feature = FEATURE_MAPPING[idx] if idx < len(FEATURE_MAPPING) else f"reserved_{idx}"
        clear = decrypt_block_bf(self.tokens[idx], self.bf)
        try:
            ascii_val = clear.decode('utf-8')
        except:
            ascii_val = ''.join(chr(c) if 32 <= c < 127 else '.' for c in clear)
        newval = simpledialog.askstring("Bearbeiten", f"Wert für [{idx}] {feature} (Hex für Flags: 00/01...)", initialvalue=clear.hex(), parent=self)
        if newval:
            try:
                newbytes = bytes.fromhex(newval.strip())
                self.tokens[idx] = encrypt_block_bf(newbytes, self.bf)
                self.load_table()
            except Exception as e:
                messagebox.showerror("Fehler", f"Ungültiger Hex-Wert: {e}")

    def save_db(self):
        parts = BASE64_REGEX.split(self.db_bytes)
        out = parts[0]
        for idx, token in enumerate(self.tokens):
            out += token + parts[idx+1]
        fname = filedialog.asksaveasfilename(initialfile=OUTPUT_DB, defaultextension=".db", filetypes=[("DB Datei", "*.db"),("Alle Dateien","*.*")])
        if fname:
            with open(fname, "wb") as f:
                f.write(out)
            messagebox.showinfo("Gespeichert", f"Geänderte DB wurde als {fname} gespeichert.")

if __name__ == "__main__":
    app = FullhanDBGUI()
    app.mainloop()
